# Gogit
Golang-based CLI wrapper for github.com

## Why ?

I'm tired of having to use my browser to create repositories, have 
informations about my issues, pull requests, etc.

I just want to have a CLI tool that'll allow me to avoid going to
github.com everytime.

Plus I like my terminal font more than my browser's, in addition to that.


## Usage

Export your freshly created 
[personnal access token](https://github.com/settings/token), as `GIT_TOKEN`

